/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: arsarkis <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/09 13:53:23 by arsarkis          #+#    #+#             */
/*   Updated: 2023/02/09 13:54:31 by arsarkis         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_PRINTF_H
# define FT_PRINTF_H

# include <stdarg.h>
# include <stdio.h>
# include <unistd.h>

int	ft_printf(char const *str, ...);

int	ft_print_char(int c);

int	ft_print_str(char *str);

int	ft_print_num(int n);

int	ft_print_unum(unsigned int num);

int	ft_print_hexnum(unsigned long long num, short x);
#endif
