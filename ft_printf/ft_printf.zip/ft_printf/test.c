#include <stdio.h>

unsigned int x = 45;

int y = 45;

int main()
{
    printf("%d\n%i", x, y);
}