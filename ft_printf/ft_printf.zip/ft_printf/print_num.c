/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   print_num.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: arsarkis <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/09 13:57:08 by arsarkis          #+#    #+#             */
/*   Updated: 2023/02/09 13:57:30 by arsarkis         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

int	ft_print_num(int n)
{
	int	count;

	count = 0;
	if (n == -2147483648)
	{
		write(1, "-2147483648", 11);
		return (11);
	}
	if (n < 0)
	{
		n *= -1;
		count += ft_print_char('-');
	}
	if (n > 9)
	{
		count += ft_print_num((n / 10));
		count += ft_print_char((n % 10 + '0'));
	}
	else
	{
		count += ft_print_char(n + '0');
	}
	return (count);
}
