/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   print_hexnum.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: arsarkis <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/09 13:56:30 by arsarkis          #+#    #+#             */
/*   Updated: 2023/02/09 13:56:49 by arsarkis         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

int	ft_print_hexnum(unsigned long long num, short x)
{
	int	count;

	count = 0;
	if (x)
	{
		if (num < 16)
			count += ft_print_char("0123456789abcdef"[num % 16]);
		else
		{
			count += ft_print_hexnum(num / 16, 1);
			count += ft_print_char("0123456789abcdef"[num % 16]);
		}
	}
	else
	{
		if (num < 16)
			count += ft_print_char("0123456789ABCDEF"[num % 16]);
		else
		{
			count += ft_print_hexnum(num / 16, 0);
			count += ft_print_char("0123456789ABCDEF"[num % 16]);
		}
	}
	return (count);
}
