#include <stdarg.h>
#include <stdio.h>
#include <unistd.h>

void    check_type(char const *str, int i, va_list argc)
{
    if (str[i + 1] == 'd')
    {
        printf("%d --> ", argc);
        va_arg (argc, int);
    }
    else if (str[i + 1] == 'i')
        va_arg (argc, int); //nay es pahy   int
    else if (str[i + 1] == 'u')
        va_arg (argc, unsigned int);
    else if (str[i + 1] == 'c')
        va_arg (argc, char);
    else if (str[i + 1] == 's')
        va_arg (argc, char *);
    else if (str[i + 1] == 'x')
        va_arg (argc, char *);
    else if (str[i + 1] == 'X')
        va_arg (argc, char *);
    else if (str[i + 1] == 'p')
        va_arg (argc, int);
    else if (str[i + 1] == '%')
        printf(str[i]);
}

int ft_printf(char const *str, ...)
{
    int     i;
    va_list argc;

    i = 0;
    va_start(argc, str);
    while (str[i] != '\0')
    {
        if (str[i] == '%')
            check_type(str, i, argc);
        i++;
    }
    va_end(argc);
    return (0);
}

int main()
{
    int x = 3;
    ft_printf("%d hello", x);
    return (0);
}