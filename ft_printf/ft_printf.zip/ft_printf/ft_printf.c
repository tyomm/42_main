/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: arsarkis <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/09 14:01:43 by arsarkis          #+#    #+#             */
/*   Updated: 2023/02/09 14:05:28 by arsarkis         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

int	check_type(char const *str, va_list argc, int count)
{
	if (*str == 'd' || *str == 'i')
		count += ft_print_num(va_arg(argc, int));
	else if (*str == 'u')
		count += ft_print_unum(va_arg(argc, unsigned int));
	else if (*str == 'c')
		count += ft_print_char(va_arg(argc, int));
	else if (*str == 's')
		count += ft_print_str(va_arg(argc, char *));
	else if (*str == 'x')
		count += ft_print_hexnum(va_arg(argc, unsigned int), 1);
	else if (*str == 'X')
		count += ft_print_hexnum(va_arg(argc, unsigned int), 0);
	else if (*str == 'p')
	{
		count += ft_print_str("0x");
		count += ft_print_hexnum(va_arg(argc, unsigned int), 1);
	}
	else if (*str == '%')
		count += ft_print_char('%');
	return (count);
}

int	ft_printf(char const *str, ...)
{
	int		count;
	va_list	argc;

	count = 0;
	va_start(argc, str);
	while (*str)
	{
		if (*str == '%' && str++)
			count += check_type(str, argc, count);
		else
			count += ft_print_char(*str);
		str++;
	}
	va_end(argc);
	return (count);
}


int main()
{
    char c = 's';
    char str[] = "barev";
    int n = 55555;

	
	ft_printf("% c %c");

	printf("\n");

	printf("% c %c");

    return (0);
}

