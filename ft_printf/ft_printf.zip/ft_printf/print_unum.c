/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   print_unum.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: arsarkis <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/09 14:00:29 by arsarkis          #+#    #+#             */
/*   Updated: 2023/02/09 14:01:24 by arsarkis         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

int	ft_print_unum(unsigned int num)
{
	int	count;

	count = 0;
	if (num > 9)
	{
		count += ft_print_unum(num / 10);
		count += ft_print_char(num % 10 + '0');
	}
	else
		count += ft_print_char(num + '0');
	return (count);
}
